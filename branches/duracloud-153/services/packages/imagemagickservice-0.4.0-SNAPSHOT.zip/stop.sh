#!/bin/bash

sudo apt-get update
sudo apt-get remove imagemagick --yes
