#!/bin/bash

sudo apt-get update
sudo apt-get install imagemagick --yes
