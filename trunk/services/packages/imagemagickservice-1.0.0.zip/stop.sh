#!/bin/bash

apt-get update
apt-get remove imagemagick --yes