#!/bin/bash

apt-get update
apt-get install imagemagick --yes